package ned.tools;

public class Entry {
	String leadId;
	int level;
	
	public Entry(String leadId, int level)
	{
		this.leadId = leadId;
		this.level = level;
	}
}
